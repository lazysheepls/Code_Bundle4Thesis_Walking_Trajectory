-------------------------------------------------------------
Appendix B: Sample data for matlab
-------------------------------------------------------------
- Set 1: Gyroscope calibration file
2015-05-21_13-10-33.csv
- Set 2: Compass calibration file
2015-05-21_13-10-50.csv
- Set 3: experiment log file
2015-05-21_13-11-03.csv