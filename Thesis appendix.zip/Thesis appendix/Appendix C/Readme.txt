------------------------------------------------------------
Appendix C: figures about accelerometer filtering

three compare groups
------------------------------------------------------------