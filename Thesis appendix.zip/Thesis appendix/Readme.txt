-------------------------------------------------------------
Appendix for Yang's thesis: 
Walking trajectory analysis using smartphone sensors
-------------------------------------------------------------
Contents:
-------------------------------------------------------------
Appendix A: Source code
A.1 Qt application spurce code
A.2 matlab source code
-------------------------------------------------------------
Appendix B: Sample data
-------------------------------------------------------------
Appendix C: Figures